import sys
import time
import threading
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTextEdit, QLineEdit, QPushButton, QLabel, QComboBox, QGroupBox,
                             QScrollArea, QSplitter, QProgressBar)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt5.QtGui import QFont, QTextCursor, QColor
import agentscope
import dashscope
from agentscope import msghub
from agentscope.agents import DialogAgent, ReActAgentV2
from agentscope.message import Msg
from agentscope.service import ServiceToolkit
from typing import Literal, Union
from pydantic import BaseModel, Field

dashscope.api_key = "sk-870d6bc67fd04cc18cef4c3941e74a56"

# 家庭成员配置
family_configs = [
    {"name": "张善", "role": "你是张武的爸爸，腰不好不能久坐，在旅游中喜欢注重行程合理性，推荐交通便利的景点"},
    {"name": "李丝", "role": "你是张武的妈妈，在旅游中优先控制总费用，推荐经济型酒店和公共交通"},
    {"name": "张柳", "role": "你是张武的儿子，喜欢调皮，在旅游中希望安排游乐场、主题公园等有趣活动"},
    {"name": "张期", "role": "你是张武的女儿，在旅游中想去漂亮的地方拍照片，不喜欢出去玩太久"}
]

# 朋友配置
friends_configs = [
    {"name": "小红",
     "role": "你是张武的朋友，不喜欢商业化过度的景点（如摆拍式网红打卡地）会破坏自然真实感，不喜欢被游客打扰拍摄和重复的风景（如千篇一律的古镇、景区），更不喜欢快节奏旅行因为无法静心观察细节。"},
    {"name": "小绿",
     "role": "你是张武的朋友，不喜欢拥挤的热门路线和不安全的路线（如无标识的小路、未开发区域）因为风险过高，希望有计划的旅行。"},
    {"name": "小白",
     "role": "你是张武的朋友，不喜欢快餐连锁店，缺乏地方特色和过度包装的'文化体验'（如商业化的民俗表演）。不喜欢浪费食物（如剩饭剩菜）和被推荐'假本地美食'（如用预制菜伪装的手工小吃）。"},
    {"name": "小蓝",
     "role": "你是张武的朋友，不喜欢没有网络信号的偏远地区（如山区、沙漠）因为无法同步数据或求助。不喜欢过度依赖人工服务（如需要排队等导游讲解）因为科技能更高效。"}
]

# 初始化模型配置 - 必须在主线程中完成
agentscope.init(
    model_configs=[
        {
            "config_name": "my_config",
            "model_type": "dashscope_chat",
            "model_name": "qwen-max",
        }
    ]
)

# 初始化工具和服务 - 必须在主线程中完成
toolkit = ServiceToolkit()
# 添加 MCP 服务器配置
toolkit.add_mcp_servers({
    "mcpServers": {
        "amap-maps": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/9f1044ff251243/sse"},
        "mcp-trends-hub": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/c8b17a7df69b4a/sse"},
        "edgeone-pages-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/a6b154c5aeef4d/sse"},
        "memory-plus": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/eb420b6015354b/sse"},
        "12306-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/334df549a6dc4c/sse"},
        "mcp-server-chart": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/4ecf51cfa7fb4a/sse"},
        "howtocook-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/1e2bf7fc3fcb40/sse"},
        "variflight-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/504a7c74775540/sse"},
        "mcp-ragdocs": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/3ea19b25054740/sse"}
    }
})

# 创建代理 - 必须在主线程中完成
routing_agent = ReActAgentV2(
    name="Routing",
    model_config_name="my_config",
    sys_prompt="你是一个路由代理，负责将用户查询路由到正确的后续任务。",
    service_toolkit=ServiceToolkit()
)

personal_agent = ReActAgentV2(
    name="personal_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="你是一个个人旅行助手，帮助用户规划个人旅行行程。"
)

family_agent = ReActAgentV2(
    name="family_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="你是一个家庭旅行助手，帮助用户规划家庭旅行行程。"
)

friends_agent = ReActAgentV2(
    name="friends_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="你是一个朋友旅行助手，帮助用户规划朋友旅行行程。"
)


# 路由选择模型
class RoutingChoice(BaseModel):
    your_choice: Literal[
        'personal travel',
        'friends travel',
        'family travel',
        None
    ] = Field(description="选择合适的选项，如果任务太简单或没有合适的任务，选择'None'")
    task_description: Union[str, None] = Field(description="任务描述", default=None)


# 家庭对话函数
def family_dialog(plans, callback=None):
    agents = [DialogAgent(config["name"], config["role"], model_config_name="my_config") for config in family_configs]
    user = DialogAgent(
        "张武",
        "你是张武，你要根据家人的意见选择最终的旅行方案，你的家人有张善（爸爸）李丝（妈妈）张柳（儿子）张期（女儿）",
        model_config_name="my_config"
    )

    greeting = Msg(
        name="张武",
        content=f"我是张武，过几天打算带大家去{plans}旅游，大家简要的聊一聊自己关于这次旅游的想法",
        role="user",
    )

    responses = []
    if callback:
        callback(f"【家庭讨论】张武发起讨论：{greeting.content}", "system")

    with msghub(participants=agents, announcement=greeting) as hub:
        for agent in agents:
            response = agent()
            responses.append(response)
            if callback:
                callback(f"【{agent.name}】: {response.content}", "family")

    if callback:
        callback("\n【汇总家庭成员意见】", "system")

    final_output = user(Msg("张武", str(responses), "user"))

    if callback:
        callback(f"【张武总结】: {final_output.content}", "user")

    return str(final_output)


# 朋友对话函数
def friends_dialog(plans, callback=None):
    agents = [DialogAgent(config["name"], config["role"], model_config_name="my_config") for config in friends_configs]
    user = DialogAgent(
        "张武",
        "你是张武，要根据朋友和自己的意见制定合适的旅游计划",
        model_config_name="my_config"
    )

    greeting = Msg(
        name="张武",
        content=f"我是张武，大家简要的聊一聊自己关于{plans}旅游的想法",
        role="user",
    )

    responses = []
    if callback:
        callback(f"【朋友讨论】张武发起讨论：{greeting.content}", "system")

    with msghub(participants=agents, announcement=greeting) as hub:
        for agent in agents:
            response = agent()
            responses.append(response)
            if callback:
                callback(f"【{agent.name}】: {response.content}", "friend")

    if callback:
        callback("\n【汇总朋友意见】", "system")

    final_output = user(Msg("张武", str(responses), "user"))

    if callback:
        callback(f"【张武总结】: {final_output.content}", "user")

    return str(final_output)


# 工作线程类，使用 threading.Thread 而不是 QThread
class PlanningThread(threading.Thread):
    def __init__(self, plans, plan_type, callback, status_callback):
        super().__init__()
        self.plans = plans
        self.plan_type = plan_type
        self.callback = callback
        self.status_callback = status_callback
        self._stop_event = threading.Event()
        self.result = None
        self.error = None

    def run(self):
        try:
            self.status_callback("规划中")
            self.callback(f"开始规划旅行：{self.plans}", "system")

            if self.plan_type == "自动识别":
                self.callback("\n【步骤1】自动识别旅行类型...", "system")
                msg = Msg("user", self.plans, "user")
                res_msg = routing_agent(
                    msg,
                    structured_model=RoutingChoice
                )
                choice = res_msg.metadata.get("your_choice", "None")
                self.callback(f"识别结果：{choice}", "system")

                if choice == "personal travel":
                    self.callback("\n【步骤2】规划个人旅行...", "system")
                    result = personal_agent(msg)
                    self.callback("\n【个人旅行计划】\n" + str(result), "result")
                    self.result = str(result)

                elif choice == "friends travel":
                    self.callback("\n【步骤2】收集朋友意见...", "system")
                    output = friends_dialog(self.plans, lambda msg, role: self.callback(msg, role))
                    content = f"朋友意见汇总：{output}\n用户需求：{self.plans}"
                    self.callback("\n【步骤3】生成朋友旅行计划...", "system")
                    friend_msg = Msg("user", content, "user")
                    result = friends_agent(friend_msg)
                    self.callback("\n【朋友旅行计划】\n" + str(result), "result")
                    self.result = str(result)

                elif choice == "family travel":
                    self.callback("\n【步骤2】收集家人意见...", "system")
                    output = family_dialog(self.plans, lambda msg, role: self.callback(msg, role))
                    content = f"家人意见汇总：{output}\n用户需求：{self.plans}"
                    self.callback("\n【步骤3】生成家庭旅行计划...", "system")
                    family_msg = Msg("user", content, "user")
                    result = family_agent(family_msg)
                    self.callback("\n【家庭旅行计划】\n" + str(result), "result")
                    self.result = str(result)

                else:
                    self.callback("无法识别旅行类型，请手动选择", "error")

            elif self.plan_type == "个人旅行":
                self.callback("\n【步骤1】规划个人旅行...", "system")
                msg = Msg("user", self.plans, "user")
                result = personal_agent(msg)
                self.callback("\n【个人旅行计划】\n" + str(result), "result")
                self.result = str(result)

            elif self.plan_type == "家庭旅行":
                self.callback("\n【步骤1】收集家人意见...", "system")
                output = family_dialog(self.plans, lambda msg, role: self.callback(msg, role))
                content = f"家人意见汇总：{output}\n用户需求：{self.plans}"
                self.callback("\n【步骤2】生成家庭旅行计划...", "system")
                family_msg = Msg("user", content, "user")
                result = family_agent(family_msg)
                self.callback("\n【家庭旅行计划】\n" + str(result), "result")
                self.result = str(result)

            elif self.plan_type == "朋友旅行":
                self.callback("\n【步骤1】收集朋友意见...", "system")
                output = friends_dialog(self.plans, lambda msg, role: self.callback(msg, role))
                content = f"朋友意见汇总：{output}\n用户需求：{self.plans}"
                self.callback("\n【步骤2】生成朋友旅行计划...", "system")
                friend_msg = Msg("user", content, "user")
                result = friends_agent(friend_msg)
                self.callback("\n【朋友旅行计划】\n" + str(result), "result")
                self.result = str(result)

            self.callback("\n✅ 旅行规划完成！", "success")
            self.status_callback("完成")

        except Exception as e:
            self.callback(f"发生错误：{str(e)}", "error")
            self.error = str(e)
            self.status_callback("错误")

    def stop(self):
        self._stop_event.set()


class TravelPlannerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("智能旅行规划助手 - 修复MCP问题版")
        self.setGeometry(100, 100, 1200, 800)

        # 初始化核心组件
        self.init_ui()

        # 工作线程
        self.planning_thread = None

        # 初始化定时器用于检测线程状态
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_thread_status)
        self.timer.start(500)  # 每500毫秒检查一次

    def init_ui(self):
        """初始化用户界面"""
        main_widget = QWidget()
        main_layout = QVBoxLayout()

        # 标题
        title_label = QLabel("智能旅行规划助手 - 修复MCP问题版")
        title_label.setFont(QFont("Arial", 18, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("color: #2c3e50; margin: 15px; background-color: #f0f8ff; padding: 10px;")

        # 输入区域
        input_group = QGroupBox("输入旅行计划")
        input_layout = QVBoxLayout()

        self.input_field = QTextEdit()
        self.input_field.setPlaceholderText("请输入您的旅行计划，例如：全家五口人计划五一去杭州玩四天，预算8000元")
        self.input_field.setMinimumHeight(100)
        self.input_field.setStyleSheet("font-size: 14px;")

        self.plan_type_combo = QComboBox()
        self.plan_type_combo.addItem("自动识别")
        self.plan_type_combo.addItem("个人旅行")
        self.plan_type_combo.addItem("家庭旅行")
        self.plan_type_combo.addItem("朋友旅行")
        self.plan_type_combo.setStyleSheet("font-size: 14px; height: 30px;")

        button_layout = QHBoxLayout()
        self.submit_btn = QPushButton("生成旅行计划")
        self.submit_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 12px 24px;
                font-size: 16px;
                font-weight: bold;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
            }
        """)
        self.submit_btn.clicked.connect(self.generate_plan)

        self.clear_btn = QPushButton("清空输出")
        self.clear_btn.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                padding: 12px 24px;
                font-size: 16px;
                font-weight: bold;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #d32f2f;
            }
        """)
        self.clear_btn.clicked.connect(self.clear_output)

        button_layout.addWidget(self.submit_btn)
        button_layout.addWidget(self.clear_btn)

        input_layout.addWidget(QLabel("旅行计划描述："))
        input_layout.addWidget(self.input_field)
        input_layout.addWidget(QLabel("旅行类型："))
        input_layout.addWidget(self.plan_type_combo)
        input_layout.addLayout(button_layout)
        input_group.setLayout(input_layout)

        # 输出区域
        output_group = QGroupBox("旅行规划过程与结果")
        output_layout = QVBoxLayout()

        self.output_field = QTextEdit()
        self.output_field.setReadOnly(True)
        self.output_field.setMinimumHeight(400)
        self.output_field.setStyleSheet("""
            QTextEdit {
                font-family: Consolas, Courier New, monospace;
                font-size: 13px;
                background-color: #f8f9fa;
                border: 1px solid #ddd;
            }
        """)

        # 添加滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(self.output_field)

        output_layout.addWidget(scroll_area)
        output_group.setLayout(output_layout)

        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)  # 不确定进度模式
        self.progress_bar.setVisible(False)

        # 信息展示区域
        info_group = QGroupBox("角色信息")
        info_layout = QHBoxLayout()

        # 家庭成员信息
        family_group = QGroupBox("家庭成员偏好")
        family_layout = QVBoxLayout()

        family_text = "\n".join([f"👨 {member['name']}：{member['role']}" for member in family_configs])
        family_label = QLabel(family_text)
        family_label.setWordWrap(True)
        family_label.setStyleSheet("font-size: 13px; padding: 10px;")

        family_layout.addWidget(family_label)
        family_group.setLayout(family_layout)

        # 朋友信息
        friends_group = QGroupBox("朋友偏好")
        friends_layout = QVBoxLayout()

        friends_text = "\n".join([f"👤 {friend['name']}：{friend['role']}" for friend in friends_configs])
        friends_label = QLabel(friends_text)
        friends_label.setWordWrap(True)
        friends_label.setStyleSheet("font-size: 13px; padding: 10px;")

        friends_layout.addWidget(friends_label)
        friends_group.setLayout(friends_layout)

        info_layout.addWidget(family_group)
        info_layout.addWidget(friends_group)
        info_group.setLayout(info_layout)

        # 主布局
        main_layout.addWidget(title_label)
        main_layout.addWidget(input_group)
        main_layout.addWidget(output_group)
        main_layout.addWidget(self.progress_bar)
        main_layout.addWidget(info_group)

        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

        # 状态栏
        self.status_bar = self.statusBar()
        self.status_bar.showMessage("就绪，请输入旅行计划...")

        # 设置窗口样式
        self.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #ddd;
                border-radius: 5px;
                margin-top: 1ex;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 5px;
            }
        """)

    def append_output(self, text, msg_type="system"):
        """在输出区域追加文本，根据消息类型设置不同样式"""
        cursor = self.output_field.textCursor()
        cursor.movePosition(QTextCursor.End)

        # 根据消息类型设置不同颜色
        if msg_type == "system":
            color = QColor("#1E88E5")  # 蓝色
        elif msg_type == "family":
            color = QColor("#43A047")  # 绿色
        elif msg_type == "friend":
            color = QColor("#7B1FA2")  # 紫色
        elif msg_type == "user":
            color = QColor("#E65100")  # 橙色
        elif msg_type == "result":
            color = QColor("#0D47A1")  # 深蓝色
            text = "\n" + "=" * 80 + "\n" + text + "\n" + "=" * 80 + "\n"
        elif msg_type == "success":
            color = QColor("#2E7D32")  # 深绿色
        elif msg_type == "error":
            color = QColor("#C62828")  # 红色
        else:
            color = QColor("#000000")  # 黑色

        # 设置文本格式
        format = cursor.charFormat()
        format.setForeground(color)

        # 对于结果消息使用粗体
        if msg_type == "result" or msg_type == "error":
            format.setFontWeight(QFont.Bold)

        cursor.setCharFormat(format)
        cursor.insertText(text + "\n")

        # 自动滚动到底部
        scrollbar = self.output_field.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def clear_output(self):
        """清空输出区域"""
        self.output_field.clear()

    def generate_plan(self):
        """生成旅行计划"""
        plans = self.input_field.toPlainText().strip()
        if not plans:
            self.status_bar.showMessage("请输入旅行计划内容")
            return

        # 清空输出区域
        self.clear_output()
        self.status_bar.showMessage("正在规划中，请稍候...")

        # 禁用按钮，防止重复提交
        self.submit_btn.setEnabled(False)
        self.submit_btn.setText("规划中...")

        # 显示进度条
        self.progress_bar.setVisible(True)

        # 获取用户选择的旅行类型
        plan_type = self.plan_type_combo.currentText()

        # 创建工作线程
        self.planning_thread = PlanningThread(
            plans=plans,
            plan_type=plan_type,
            callback=self.append_output,
            status_callback=self.status_bar.showMessage
        )

        # 启动线程
        self.planning_thread.start()

    def check_thread_status(self):
        """检查线程状态，完成后启用按钮"""
        if self.planning_thread and not self.planning_thread.is_alive():
            # 线程已完成
            self.submit_btn.setEnabled(True)
            self.submit_btn.setText("生成旅行计划")
            self.progress_bar.setVisible(False)

            if self.planning_thread.error:
                self.status_bar.showMessage(f"错误: {self.planning_thread.error}")
            else:
                self.status_bar.showMessage("旅行规划完成！")

            # 重置线程引用
            self.planning_thread = None

    def closeEvent(self, event):
        """窗口关闭事件，确保线程安全退出"""
        if self.planning_thread and self.planning_thread.is_alive():
            self.planning_thread.stop()
            self.planning_thread.join(2.0)  # 等待2秒

        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TravelPlannerApp()
    window.show()
    sys.exit(app.exec_())
