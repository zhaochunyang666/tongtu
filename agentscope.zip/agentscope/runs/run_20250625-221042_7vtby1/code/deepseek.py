import sys
import time
import threading
import queue
import traceback
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTextEdit, QLineEdit, QPushButton, QLabel, QComboBox, QGroupBox,
                             QScrollArea, QSplitter, QProgressBar, QMessageBox)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer, QObject
from PyQt5.QtGui import QFont, QTextCursor, QColor
import agentscope
import dashscope
from agentscope import msghub
from agentscope.agents import DialogAgent, ReActAgentV2
from agentscope.message import Msg
from agentscope.service import ServiceToolkit, mcp_manager
from typing import Literal, Union
from pydantic import BaseModel, Field

dashscope.api_key = "sk-870d6bc67fd04cc18cef4c3941e74a56"

# 家庭成员配置
family_configs = [
    {"name": "张善", "role": "你是张武的爸爸，腰不好不能久坐，在旅游中喜欢注重行程合理性，推荐交通便利的景点"},
    {"name": "李丝", "role": "你是张武的妈妈，在旅游中优先控制总费用，推荐经济型酒店和公共交通"},
    {"name": "张柳", "role": "你是张武的儿子，喜欢调皮，在旅游中希望安排游乐场、主题公园等有趣活动"},
    {"name": "张期", "role": "你是张武的女儿，在旅游中想去漂亮的地方拍照片，不喜欢出去玩太久"}
]

# 朋友配置
friends_configs = [
    {"name": "小红",
     "role": "你是张武的朋友，不喜欢商业化过度的景点（如摆拍式网红打卡地）会破坏自然真实感，不喜欢被游客打扰拍摄和重复的风景（如千篇一律的古镇、景区），更不喜欢快节奏旅行因为无法静心观察细节。"},
    {"name": "小绿",
     "role": "你是张武的朋友，不喜欢拥挤的热门路线和不安全的路线（如无标识的小路、未开发区域）因为风险过高，希望有计划的旅行。"},
    {"name": "小白",
     "role": "你是张武的朋友，不喜欢快餐连锁店，缺乏地方特色和过度包装的'文化体验'（如商业化的民俗表演）。不喜欢浪费食物（如剩饭剩菜）和被推荐'假本地美食'（如用预制菜伪装的手工小吃）。"},
    {"name": "小蓝",
     "role": "你是张武的朋友，不喜欢没有网络信号的偏远地区（如山区、沙漠）因为无法同步数据或求助。不喜欢过度依赖人工服务（如需要排队等导游讲解）因为科技能更高效。"}
]


# 在主线程中初始化agentscope
def init_agentscope():
    agentscope.init(
        model_configs=[
            {
                "config_name": "my_config",
                "model_type": "dashscope_chat",
                "model_name": "qwen-max",
            }
        ]
    )


# 在主线程中初始化MCP服务
def init_mcp_service():
    toolkit = ServiceToolkit()
    toolkit.add_mcp_servers({
        "mcpServers": {
            "amap-maps": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/9f1044ff251243/sse"},
            "mcp-trends-hub": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/c8b17a7df69b4a/sse"},
            "edgeone-pages-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/a6b154c5aeef4d/sse"},
            "memory-plus": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/eb420b6015354b/sse"},
            "12306-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/334df549a6dc4c/sse"},
            "mcp-server-chart": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/4ecf51cfa7fb4a/sse"},
            "howtocook-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/1e2bf7fc3fcb40/sse"},
            "variflight-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/504a7c74775540/sse"},
            "mcp-ragdocs": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/3ea19b25054740/sse"}
        }
    })
    return toolkit


# 路由选择模型
class RoutingChoice(BaseModel):
    your_choice: Literal[
        'personal travel',
        'friends travel',
        'family travel',
        None
    ] = Field(description="选择合适的选项，如果任务太简单或没有合适的任务，选择'None'")
    task_description: Union[str, None] = Field(description="任务描述", default=None)


# MCP服务工作线程
class McpWorker(QObject):
    tool_call_finished = pyqtSignal(str, object)  # (tool_name, result)
    tool_call_failed = pyqtSignal(str, str)  # (tool_name, error)

    def __init__(self):
        super().__init__()
        self.tool_queue = queue.Queue()
        self.running = True
        self.thread = threading.Thread(target=self.run)
        self.thread.daemon = True
        self.thread.start()

    def run(self):
        while self.running:
            try:
                # 从队列获取工具调用请求
                tool_name, args, kwargs = self.tool_queue.get(timeout=1)

                try:
                    # 执行MCP工具调用
                    result = mcp_manager.execute_tool(tool_name, *args, **kwargs)
                    self.tool_call_finished.emit(tool_name, result)
                except Exception as e:
                    self.tool_call_failed.emit(tool_name, str(e))
            except queue.Empty:
                continue
            except Exception as e:
                print(f"McpWorker error: {str(e)}")

    def call_tool(self, tool_name, *args, **kwargs):
        self.tool_queue.put((tool_name, args, kwargs))

    def stop(self):
        self.running = False
        self.thread.join(timeout=2)


# 自定义ReActAgentV2，处理MCP调用
class SafeReActAgentV2(ReActAgentV2):
    def __init__(self, mcp_worker, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.mcp_worker = mcp_worker
        self.current_tool_call = None
        self.tool_result = None
        self.tool_error = None

    def _execute_tool(self, tool_name, *args, **kwargs):
        # 使用MCP工作线程执行工具调用
        self.current_tool_call = tool_name
        self.tool_result = None
        self.tool_error = None

        # 向MCP工作线程发送请求
        self.mcp_worker.call_tool(tool_name, *args, **kwargs)

        # 等待工具调用完成
        while self.tool_result is None and self.tool_error is None:
            time.sleep(0.1)

        if self.tool_error:
            raise RuntimeError(f"Tool {tool_name} failed: {self.tool_error}")

        return self.tool_result

    def handle_tool_result(self, tool_name, result):
        if tool_name == self.current_tool_call:
            self.tool_result = result

    def handle_tool_error(self, tool_name, error):
        if tool_name == self.current_tool_call:
            self.tool_error = error


# 规划工作线程
class PlanningThread(QThread):
    # 定义信号
    output_signal = pyqtSignal(str, str)  # (text, msg_type)
    planning_finished = pyqtSignal()
    planning_error = pyqtSignal(str)
    choice_identified = pyqtSignal(str)
    family_opinion_signal = pyqtSignal(str, str)  # (name, content)
    friend_opinion_signal = pyqtSignal(str, str)  # (name, content)
    summary_signal = pyqtSignal(str, str)  # (name, content)
    result_signal = pyqtSignal(str)

    def __init__(self, app, plans, plan_type):
        super().__init__()
        self.app = app
        self.plans = plans
        self.plan_type = plan_type
        self.running = True

    def run(self):
        try:
            self.output_signal.emit(f"开始规划旅行：{self.plans}", "system")

            if self.plan_type == "自动识别":
                self.output_signal.emit("\n【步骤1】自动识别旅行类型...", "system")
                msg = Msg("user", self.plans, "user")

                try:
                    # 安全调用路由代理
                    res_msg = self.app.routing_agent(
                        msg,
                        structured_model=RoutingChoice
                    )

                    # 安全获取路由选择结果
                    if res_msg.metadata and "your_choice" in res_msg.metadata:
                        choice = res_msg.metadata["your_choice"]
                    else:
                        # 尝试从内容中解析选择结果
                        choice = self.parse_choice_from_content(res_msg.content)
                        if not choice:
                            self.output_signal.emit("无法从路由代理获取选择结果，使用默认值", "warning")
                            choice = "None"

                    self.choice_identified.emit(choice)

                    if choice == "personal travel":
                        self.output_signal.emit("\n【步骤2】规划个人旅行...", "system")
                        result = self.app.personal_agent(msg)
                        self.result_signal.emit("\n【个人旅行计划】\n" + str(result))

                    elif choice == "friends travel":
                        self.output_signal.emit("\n【步骤2】收集朋友意见...", "system")
                        output = self.friends_dialog(self.plans)
                        content = f"朋友意见汇总：{output}\n用户需求：{self.plans}"
                        self.output_signal.emit("\n【步骤3】生成朋友旅行计划...", "system")
                        friend_msg = Msg("user", content, "user")
                        result = self.app.friends_agent(friend_msg)
                        self.result_signal.emit("\n【朋友旅行计划】\n" + str(result))

                    elif choice == "family travel":
                        self.output_signal.emit("\n【步骤2】收集家人意见...", "system")
                        output = self.family_dialog(self.plans)
                        content = f"家人意见汇总：{output}\n用户需求：{self.plans}"
                        self.output_signal.emit("\n【步骤3】生成家庭旅行计划...", "system")
                        family_msg = Msg("user", content, "user")
                        result = self.app.family_agent(family_msg)
                        self.result_signal.emit("\n【家庭旅行计划】\n" + str(result))

                    else:
                        self.output_signal.emit("无法识别旅行类型，请手动选择", "error")

                except Exception as e:
                    self.output_signal.emit(f"路由代理调用失败: {str(e)}", "error")
                    self.output_signal.emit("尝试直接生成个人旅行计划...", "system")
                    result = self.app.personal_agent(msg)
                    self.result_signal.emit("\n【个人旅行计划】\n" + str(result))

            elif self.plan_type == "个人旅行":
                self.output_signal.emit("\n【步骤1】规划个人旅行...", "system")
                msg = Msg("user", self.plans, "user")
                result = self.app.personal_agent(msg)
                self.result_signal.emit("\n【个人旅行计划】\n" + str(result))

            elif self.plan_type == "家庭旅行":
                self.output_signal.emit("\n【步骤1】收集家人意见...", "system")
                output = self.family_dialog(self.plans)
                content = f"家人意见汇总：{output}\n用户需求：{self.plans}"
                self.output_signal.emit("\n【步骤2】生成家庭旅行计划...", "system")
                family_msg = Msg("user", content, "user")
                result = self.app.family_agent(family_msg)
                self.result_signal.emit("\n【家庭旅行计划】\n" + str(result))

            elif self.plan_type == "朋友旅行":
                self.output_signal.emit("\n【步骤1】收集朋友意见...", "system")
                output = self.friends_dialog(self.plans)
                content = f"朋友意见汇总：{output}\n用户需求：{self.plans}"
                self.output_signal.emit("\n【步骤2】生成朋友旅行计划...", "system")
                friend_msg = Msg("user", content, "user")
                result = self.app.friends_agent(friend_msg)
                self.result_signal.emit("\n【朋友旅行计划】\n" + str(result))

            self.output_signal.emit("\n✅ 旅行规划完成！", "success")
            self.planning_finished.emit()

        except Exception as e:
            error_msg = f"规划过程中发生错误: {str(e)}\n{traceback.format_exc()}"
            self.planning_error.emit(error_msg)

    def parse_choice_from_content(self, content):
        """从代理响应内容中解析选择结果"""
        try:
            # 尝试解析JSON格式的响应
            import json
            data = json.loads(content)
            if "your_choice" in data:
                return data["your_choice"]
        except:
            pass

        # 尝试从文本中提取关键词
        if "personal travel" in content.lower():
            return "personal travel"
        elif "friends travel" in content.lower():
            return "friends travel"
        elif "family travel" in content.lower():
            return "family travel"

        return None

    # 家庭对话函数
    def family_dialog(self, plans):
        agents = [DialogAgent(config["name"], config["role"], model_config_name="my_config") for config in
                  family_configs]
        user = DialogAgent(
            "张武",
            "你是张武，你要根据家人的意见选择最终的旅行方案，你的家人有张善（爸爸）李丝（妈妈）张柳（儿子）张期（女儿）",
            model_config_name="my_config"
        )

        greeting = Msg(
            name="张武",
            content=f"我是张武，过几天打算带大家去{plans}旅游，大家简要的聊一聊自己关于这次旅游的想法",
            role="user",
        )

        responses = []
        self.output_signal.emit(f"【家庭讨论】张武发起讨论：{greeting.content}", "system")

        with msghub(participants=agents, announcement=greeting) as hub:
            for agent in agents:
                response = agent()
                responses.append(response)
                self.family_opinion_signal.emit(agent.name, response.content)

        self.output_signal.emit("\n【汇总家庭成员意见】", "system")

        final_output = user(Msg("张武", str(responses), "user"))
        self.summary_signal.emit("张武总结", final_output.content)

        return str(final_output)

    # 朋友对话函数
    def friends_dialog(self, plans):
        agents = [DialogAgent(config["name"], config["role"], model_config_name="my_config") for config in
                  friends_configs]
        user = DialogAgent(
            "张武",
            "你是张武，要根据朋友和自己的意见制定合适的旅游计划",
            model_config_name="my_config"
        )

        greeting = Msg(
            name="张武",
            content=f"我是张武，大家简要的聊一聊自己关于{plans}旅游的想法",
            role="user",
        )

        responses = []
        self.output_signal.emit(f"【朋友讨论】张武发起讨论：{greeting.content}", "system")

        with msghub(participants=agents, announcement=greeting) as hub:
            for agent in agents:
                response = agent()
                responses.append(response)
                self.friend_opinion_signal.emit(agent.name, response.content)

        self.output_signal.emit("\n【汇总朋友意见】", "system")

        final_output = user(Msg("张武", str(responses), "user"))
        self.summary_signal.emit("张武总结", final_output.content)

        return str(final_output)


# 主应用
class TravelPlannerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("智能旅行规划助手 - 实时输出版")
        self.setGeometry(100, 100, 1200, 800)

        # 初始化核心组件
        self.init_ui()

        # 初始化定时器用于检测线程状态
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_thread_status)
        self.timer.start(500)  # 每500毫秒检查一次

        # 初始化MCP工作线程
        self.mcp_worker = McpWorker()
        self.mcp_worker.tool_call_finished.connect(self.on_tool_call_finished)
        self.mcp_worker.tool_call_failed.connect(self.on_tool_call_failed)

        # 在主线程中初始化agentscope和MCP服务
        init_agentscope()
        toolkit = init_mcp_service()

        # 创建代理
        self.routing_agent = SafeReActAgentV2(
            self.mcp_worker,
            name="Routing",
            model_config_name="my_config",
            sys_prompt="你是一个路由代理，负责将用户查询路由到正确的后续任务。",
            service_toolkit=ServiceToolkit(),

        )

        self.personal_agent = SafeReActAgentV2(
            self.mcp_worker,
            name="personal_agent",
            model_config_name="my_config",
            service_toolkit=toolkit,
            sys_prompt="你是一个个人旅行助手，帮助用户规划个人旅行行程。",

        )

        self.family_agent = SafeReActAgentV2(
            self.mcp_worker,
            name="family_agent",
            model_config_name="my_config",
            service_toolkit=toolkit,
            sys_prompt="你是一个家庭旅行助手，帮助用户规划家庭旅行行程。",

        )

        self.friends_agent = SafeReActAgentV2(
            self.mcp_worker,
            name="friends_agent",
            model_config_name="my_config",
            service_toolkit=toolkit,
            sys_prompt="你是一个朋友旅行助手，帮助用户规划朋友旅行行程。",

        )

        # 连接代理到工具结果处理
        self.mcp_worker.tool_call_finished.connect(self.handle_agent_tool_result)
        self.mcp_worker.tool_call_failed.connect(self.handle_agent_tool_error)

    def handle_agent_tool_result(self, tool_name, result):
        """将工具结果传递给所有代理"""
        self.routing_agent.handle_tool_result(tool_name, result)
        self.personal_agent.handle_tool_result(tool_name, result)
        self.family_agent.handle_tool_result(tool_name, result)
        self.friends_agent.handle_tool_result(tool_name, result)

    def handle_agent_tool_error(self, tool_name, error):
        """将工具错误传递给所有代理"""
        self.routing_agent.handle_tool_error(tool_name, error)
        self.personal_agent.handle_tool_error(tool_name, error)
        self.family_agent.handle_tool_error(tool_name, error)
        self.friends_agent.handle_tool_error(tool_name, error)

    def on_tool_call_finished(self, tool_name, result):
        """工具调用完成处理"""
        self.append_output(f"MCP服务调用成功: {tool_name} → {str(result)[:100]}...", "system")

    def on_tool_call_failed(self, tool_name, error):
        """工具调用失败处理"""
        self.append_output(f"⚠️ MCP服务调用失败: {tool_name} → {error}", "error")

    def init_ui(self):
        """初始化用户界面"""
        main_widget = QWidget()
        main_layout = QVBoxLayout()

        # 标题
        title_label = QLabel("智能旅行规划助手 - 实时输出版")
        title_label.setFont(QFont("Arial", 18, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("color: #2c3e50; margin: 15px; background-color: #f0f8ff; padding: 10px;")

        # 输入区域
        input_group = QGroupBox("输入旅行计划")
        input_layout = QVBoxLayout()

        self.input_field = QTextEdit()
        self.input_field.setPlaceholderText("请输入您的旅行计划，例如：全家五口人计划五一去杭州玩四天，预算8000元")
        self.input_field.setMinimumHeight(100)
        self.input_field.setStyleSheet("font-size: 14px;")

        self.plan_type_combo = QComboBox()
        self.plan_type_combo.addItem("自动识别")
        self.plan_type_combo.addItem("个人旅行")
        self.plan_type_combo.addItem("家庭旅行")
        self.plan_type_combo.addItem("朋友旅行")
        self.plan_type_combo.setStyleSheet("font-size: 14px; height: 30px;")

        button_layout = QHBoxLayout()
        self.submit_btn = QPushButton("生成旅行计划")
        self.submit_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 12px 24px;
                font-size: 16px;
                font-weight: bold;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
            }
        """)
        self.submit_btn.clicked.connect(self.generate_plan)

        self.clear_btn = QPushButton("清空输出")
        self.clear_btn.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                padding: 12px 24px;
                font-size: 16px;
                font-weight: bold;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #d32f2f;
            }
        """)
        self.clear_btn.clicked.connect(self.clear_output)

        button_layout.addWidget(self.submit_btn)
        button_layout.addWidget(self.clear_btn)

        input_layout.addWidget(QLabel("旅行计划描述："))
        input_layout.addWidget(self.input_field)
        input_layout.addWidget(QLabel("旅行类型："))
        input_layout.addWidget(self.plan_type_combo)
        input_layout.addLayout(button_layout)
        input_group.setLayout(input_layout)

        # 输出区域
        output_group = QGroupBox("旅行规划过程与结果")
        output_layout = QVBoxLayout()

        self.output_field = QTextEdit()
        self.output_field.setReadOnly(True)
        self.output_field.setMinimumHeight(400)
        self.output_field.setStyleSheet("""
            QTextEdit {
                font-family: Consolas, Courier New, monospace;
                font-size: 13px;
                background-color: #f8f9fa;
                border: 1px solid #ddd;
            }
        """)

        # 添加滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(self.output_field)

        output_layout.addWidget(scroll_area)
        output_group.setLayout(output_layout)

        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)  # 不确定进度模式
        self.progress_bar.setVisible(False)

        # 信息展示区域
        info_group = QGroupBox("角色信息")
        info_layout = QHBoxLayout()

        # 家庭成员信息
        family_group = QGroupBox("家庭成员偏好")
        family_layout = QVBoxLayout()

        family_text = "\n".join([f"👨 {member['name']}：{member['role']}" for member in family_configs])
        family_label = QLabel(family_text)
        family_label.setWordWrap(True)
        family_label.setStyleSheet("font-size: 13px; padding: 10px;")

        family_layout.addWidget(family_label)
        family_group.setLayout(family_layout)

        # 朋友信息
        friends_group = QGroupBox("朋友偏好")
        friends_layout = QVBoxLayout()

        friends_text = "\n".join([f"👤 {friend['name']}：{friend['role']}" for friend in friends_configs])
        friends_label = QLabel(friends_text)
        friends_label.setWordWrap(True)
        friends_label.setStyleSheet("font-size: 13px; padding: 10px;")

        friends_layout.addWidget(friends_label)
        friends_group.setLayout(friends_layout)

        info_layout.addWidget(family_group)
        info_layout.addWidget(friends_group)
        info_group.setLayout(info_layout)

        # 主布局
        main_layout.addWidget(title_label)
        main_layout.addWidget(input_group)
        main_layout.addWidget(output_group)
        main_layout.addWidget(self.progress_bar)
        main_layout.addWidget(info_group)

        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

        # 状态栏
        self.status_bar = self.statusBar()
        self.status_bar.showMessage("就绪，请输入旅行计划...")

        # 设置窗口样式
        self.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                border: 1px solid #ddd;
                border-radius: 5px;
                margin-top: 1ex;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 5px;
            }
        """)

    def append_output(self, text, msg_type="system"):
        """在输出区域追加文本，根据消息类型设置不同样式"""
        cursor = self.output_field.textCursor()
        cursor.movePosition(QTextCursor.End)

        # 根据消息类型设置不同颜色
        if msg_type == "system":
            color = QColor("#1E88E5")  # 蓝色
        elif msg_type == "family":
            color = QColor("#43A047")  # 绿色
        elif msg_type == "friend":
            color = QColor("#7B1FA2")  # 紫色
        elif msg_type == "user":
            color = QColor("#E65100")  # 橙色
        elif msg_type == "result":
            color = QColor("#0D47A1")  # 深蓝色
            text = "\n" + "=" * 80 + "\n" + text + "\n" + "=" * 80 + "\n"
        elif msg_type == "success":
            color = QColor("#2E7D32")  # 深绿色
        elif msg_type == "error":
            color = QColor("#C62828")  # 红色
        else:
            color = QColor("#000000")  # 黑色

        # 设置文本格式
        format = cursor.charFormat()
        format.setForeground(color)

        # 对于结果消息使用粗体
        if msg_type == "result" or msg_type == "error":
            format.setFontWeight(QFont.Bold)

        cursor.setCharFormat(format)
        cursor.insertText(text + "\n")

        # 自动滚动到底部
        scrollbar = self.output_field.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def clear_output(self):
        """清空输出区域"""
        self.output_field.clear()

    def generate_plan(self):
        """生成旅行计划"""
        plans = self.input_field.toPlainText().strip()
        if not plans:
            self.status_bar.showMessage("请输入旅行计划内容")
            return

        # 清空输出区域
        self.clear_output()
        self.status_bar.showMessage("正在规划中，请稍候...")

        # 禁用按钮，防止重复提交
        self.submit_btn.setEnabled(False)
        self.submit_btn.setText("规划中...")

        # 显示进度条
        self.progress_bar.setVisible(True)

        # 获取用户选择的旅行类型
        plan_type = self.plan_type_combo.currentText()

        # 创建工作线程
        self.planning_thread = PlanningThread(self, plans, plan_type)

        # 连接信号
        self.planning_thread.output_signal.connect(self.append_output)
        self.planning_thread.planning_finished.connect(self.on_planning_finished)
        self.planning_thread.planning_error.connect(self.on_planning_error)
        self.planning_thread.choice_identified.connect(self.on_choice_identified)
        self.planning_thread.family_opinion_signal.connect(self.on_family_opinion)
        self.planning_thread.friend_opinion_signal.connect(self.on_friend_opinion)
        self.planning_thread.summary_signal.connect(self.on_summary)
        self.planning_thread.result_signal.connect(self.on_result)

        # 启动线程
        self.planning_thread.start()

    def on_planning_finished(self):
        """规划完成处理"""
        self.status_bar.showMessage("旅行规划完成！")
        self.submit_btn.setEnabled(True)
        self.submit_btn.setText("生成旅行计划")
        self.progress_bar.setVisible(False)

    def on_planning_error(self, error_msg):
        """规划错误处理"""
        self.append_output(error_msg, "error")
        self.status_bar.showMessage(f"错误: {error_msg[:50]}")
        self.submit_btn.setEnabled(True)
        self.submit_btn.setText("生成旅行计划")
        self.progress_bar.setVisible(False)

    def on_choice_identified(self, choice):
        """处理旅行类型识别结果"""
        self.append_output(f"识别结果：{choice}", "system")

    def on_family_opinion(self, name, content):
        """处理家庭成员意见"""
        self.append_output(f"【{name}】: {content}", "family")

    def on_friend_opinion(self, name, content):
        """处理朋友意见"""
        self.append_output(f"【{name}】: {content}", "friend")

    def on_summary(self, name, content):
        """处理总结意见"""
        self.append_output(f"【{name}】: {content}", "user")

    def on_result(self, result):
        """处理最终结果"""
        self.append_output(result, "result")

    def check_thread_status(self):
        """保留用于其他异步任务"""
        pass

    def closeEvent(self, event):
        """窗口关闭事件，确保线程安全退出"""
        if hasattr(self, 'mcp_worker'):
            self.mcp_worker.stop()

        if hasattr(self, 'planning_thread') and self.planning_thread.isRunning():
            self.planning_thread.running = False
            self.planning_thread.wait(2000)  # 等待线程结束

        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TravelPlannerApp()
    window.show()
    sys.exit(app.exec_())
