import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QPushButton, QLabel
)
from PyQt5.QtCore import Qt
from agentscope import msghub
from agentscope.agents import DialogAgent, ReActAgentV2
from agentscope.message import Msg
import agentscope
from agentscope.service import ServiceToolkit
import dashscope

from workflow import res_msg

# 设置 DashScope API Key
dashscope.api_key = "sk-870d6bc67fd04cc18cef4c3941e74a56"

# 家庭成员配置
family_configs = [
    {"name": "张善", "role": "你是张武的爸爸，腰不好不能久坐，在旅游中喜欢注重行程合理性，推荐交通便利的景点"},
    {"name": "李丝", "role": "你是张武的妈妈，在旅游中优先控制总费用，推荐经济型酒店和公共交通"},
    {"name": "张柳", "role": "你是张武的儿子，喜欢调皮，在旅游中希望安排游乐场、主题公园等有趣活动"},
    {"name": "张期", "role": "你是张武的女儿，在旅游中想去漂亮的地方拍照片，不喜欢出去玩太久"}
]

# 朋友配置
friends_configs = [
    {"name": "小红", "role": "你是张武的朋友，不喜欢商业化过度的景点（如摆拍式网红打卡地）会破坏自然真实感，不喜欢被游客打扰拍摄和重复的风景（如千篇一律的古镇、景区），更不喜欢快节奏旅行因为无法静心观察细节。"},
    {"name": "小绿", "role": "你是张武的朋友，不喜欢拥挤的热门路线和不安全的路线（如无标识的小路、未开发区域）因为风险过高，希望有计划的旅行。"},
    {"name": "小白", "role": "你是张武的朋友，不喜欢快餐连锁店，缺乏地方特色和过度包装的“文化体验”（如商业化的民俗表演）。不喜欢浪费食物（如剩饭剩菜）和被推荐“假本地美食”（如用预制菜伪装的手工小吃）。"},
    {"name": "小蓝", "role": "你是张武的朋友，不喜欢没有网络信号的偏远地区（如山区、沙漠）因为无法同步数据或求助。不喜欢过度依赖人工服务（如需要排队等导游讲解）因为科技能更高效。"}
]

# 初始化 agentscope 模型配置
agentscope.init(
    model_configs=[
        {
            "config_name": "my_config",
            "model_type": "dashscope_chat",
            "model_name": "qwen-max",
        }
    ]
)

# 创建工具包（示例）
toolkit = ServiceToolkit()
toolkit.add_mcp_servers({
        "mcpServers": {
            "amap-maps": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/9f1044ff251243/sse"},
            "mcp-trends-hub": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/c8b17a7df69b4a/sse"},
            "edgeone-pages-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/a6b154c5aeef4d/sse"},
            "memory-plus": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/eb420b6015354b/sse"},
            "12306-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/334df549a6dc4c/sse"},
            "mcp-server-chart": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/4ecf51cfa7fb4a/sse"},
            "howtocook-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/1e2bf7fc3fcb40/sse"},
            "variflight-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/504a7c74775540/sse"},
            "mcp-ragdocs": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/3ea19b25054740/sse"}
        }
    })

# 创建代理
personal_agent = ReActAgentV2(
    name="personal_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="You're a helpful assistant named personalAgent."
)
family_agent = ReActAgentV2(
    name="family_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="You're a helpful assistant named familyAgent."
)
friends_agent = ReActAgentV2(
    name="friends_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="You're a helpful assistant named friendsAgent."
)
routing_agent = ReActAgentV2(
    name="Routing",
    model_config_name="my_config",
    sys_prompt="You're a routing agent. Your target is to route the user query to the right follow-up task",
    service_toolkit=ServiceToolkit()
)

# 路由选择模型
class RoutingChoice:
    def __init__(self):
        self.your_choice = None
        self.task_description = None

# 家庭对话函数
def famliyDialog(plans):
    agents_dict = {
        DialogAgent(config["name"], config["role"], model_config_name="my_config")
        for config in family_configs
    }
    greeting = Msg(
        name="张武",
        content="我是张武，过几天打算带大家去北京旅游，大家简要的聊一聊自己关于这次旅游的想法",
        role="user",
    )
    user = DialogAgent("张武",
                       "你是张武，你要根据家人的意见选择最终的旅行方案，你的家人有张善（爸爸）李丝（妈妈）张柳（儿子）张期（女儿）",
                       model_config_name="my_config")
    response = []
    with msghub(participants=list(agents_dict), announcement=greeting) as hub:
        for agent in agents_dict:
            response.append(agent(Msg("user", plans, "user")))
        finalOutput = user(Msg("张武", str(response), "user"))
        return finalOutput.content

# 朋友对话函数
def friendsDialog(plans):
    agents_dict = {
        DialogAgent(config["name"], config["role"], model_config_name="my_config")
        for config in friends_configs
    }
    greeting = Msg(
        name="张武",
        content="我是张武，大家简要的聊一聊自己关于这次旅游的想法",
        role="user",
    )
    user = DialogAgent("张武",
                       "你是张武，要根据朋友和自己的意见制定合适的旅游计划",
                       model_config_name="my_config")
    response = []
    with msghub(participants=list(agents_dict), announcement=greeting) as hub:
        for agent in agents_dict:
            response.append(agent(Msg("user", plans, "user")))
        finalOutput = user(Msg("张武", str(response), "user"))
        return finalOutput.content

# 主界面类
class TravelPlannerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("旅行计划助手")
        self.setGeometry(100, 100, 800, 600)

        # 主布局
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout()

        # 输入区域
        self.input_label = QLabel("请输入旅行计划信息：")
        self.input_box = QLineEdit()
        self.input_box.setPlaceholderText("例如：北京三日游，预算5000元...")

        # 按钮区域
        button_layout = QHBoxLayout()
        self.submit_button = QPushButton("提交")
        self.exit_button = QPushButton("退出")
        button_layout.addWidget(self.submit_button)
        button_layout.addWidget(self.exit_button)

        # 结果显示区域
        self.output_area = QTextEdit()
        self.output_area.setReadOnly(True)

        # 添加组件到布局
        layout.addWidget(self.input_label)
        layout.addWidget(self.input_box)
        layout.addLayout(button_layout)
        layout.addWidget(self.output_area)

        # 连接信号
        self.submit_button.clicked.connect(self.handle_submit)
        self.exit_button.clicked.connect(self.close)

        main_widget.setLayout(layout)

    def handle_submit(self):
        plans = self.input_box.text().strip()
        if not plans:
            self.output_area.setText("请输入旅行计划信息！")
            return

        # 调用路由代理
        msg = Msg("user", plans, "user")
        res_msg=routing_agent(msg, structured_model=RoutingChoice)
        # routing_choice = RoutingChoice()
        # routing_choice.your_choice = "family travel"  # 示例默认选择家庭旅行
        # 实际应调用 routing_agent(msg, structured_model=RoutingChoice) 获取结果

        # 模拟路由代理输出
        if res_msg.metadata["your_choice"] == "personal travel":
            result = personal_agent(Msg("user", plans, "user")).content

        elif res_msg.metadata["your_choice"] == "friends travel":
            result = friendsDialog(plans)
        elif res_msg.metadata["your_choice"] == "family travel":

            result = famliyDialog(plans)

            friend_msg = Msg("user", plans+result, "user")
            result = friends_agent(friend_msg)

        else:
            result = "无法识别旅行类型，请重新输入。"

        # 显示结果
        self.output_area.setText(result)

# 启动应用
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TravelPlannerApp()
    window.show()
    sys.exit(app.exec_())