// frontend/src/App.js - 前端React应用
import React, { useState } from 'react';
import './App.css';

function App() {
  const [plans, setPlans] = useState('');
  const [resultId, setResultId] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!plans.trim()) {
      setError('请输入旅行计划信息');
      return;
    }

    setError('');
    setLoading(true);
    setResult(null);

    try {
      const response = await fetch('http://localhost:5000/api/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ plans })
      });

      const data = await response.json();
      if (data.result_id) {
        setResultId(data.result_id);
        checkResult(data.result_id);
      } else {
        setError('提交失败，请重试');
        setLoading(false);
      }
    } catch (err) {
      setError('网络错误，请重试');
      setLoading(false);
    }
  };

  const checkResult = (id) => {
    const interval = setInterval(async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/result/${id}`);
        const data = await response.json();

        if (data.status === 'completed' || data.status === 'error') {
          clearInterval(interval);
          setResult(data);
          setLoading(false);
        } else {
          setResult(data);
        }
      } catch (err) {
        clearInterval(interval);
        setError('获取结果失败');
        setLoading(false);
      }
    }, 1000);
  };

  const resetForm = () => {
    setPlans('');
    setResultId('');
    setResult(null);
    setError('');
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <h1>旅行计划智能助手</h1>
        <p>根据您的需求，为您和家人或朋友制定完美的旅行计划</p>
      </header>

      <div className="content-container">
        {!resultId ? (
          <div className="input-section">
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="plans">请输入您的旅行计划需求：</label>
                <textarea
                  id="plans"
                  value={plans}
                  onChange={(e) => setPlans(e.target.value)}
                  placeholder="例如：我想和家人去北京旅游3天，预算5000元..."
                  rows={6}
                />
              </div>

              {error && <div className="error-message">{error}</div>}

              <div className="examples">
                <h3>示例输入：</h3>
                <ul>
                  <li>"我想和家人去三亚度假5天，预算8000元，有老人和孩子"</li>
                  <li>"和朋友们一起去成都玩4天，想吃地道美食，参观文化景点"</li>
                  <li>"个人去云南旅游一周，喜欢自然风光和摄影"</li>
                </ul>
              </div>

              <button type="submit" disabled={loading} className="submit-btn">
                {loading ? '处理中...' : '生成旅行计划'}
              </button>
            </form>
          </div>
        ) : (
          <div className="result-section">
            {result ? (
              <>
                <div className="result-header">
                  <h2>旅行计划结果</h2>
                  <button onClick={resetForm} className="new-btn">创建新计划</button>
                </div>

                {result.status === 'error' ? (
                  <div className="error-result">
                    <h3>处理失败</h3>
                    <p>{result.result}</p>
                  </div>
                ) : (
                  <div className="success-result">
                    <div className="result-meta">
                      <div className="meta-item">
                        <strong>状态:</strong> {result.status === 'completed' ? '已完成' : '处理中'}
                      </div>
                      <div className="meta-item">
                        <strong>当前步骤:</strong> {result.step}
                      </div>
                    </div>

                    <div className="result-content">
                      <h3>旅行计划详情:</h3>
                      <div className="plan-details">
                        {result.result.split('\n').map((line, index) => (
                          <p key={index}>{line}</p>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="loading-result">
                <div className="spinner"></div>
                <p>正在处理您的旅行计划，请稍候...</p>
              </div>
            )}
          </div>
        )}
      </div>

      <footer className="app-footer">
        <p>© 2023 旅行计划智能助手 | 使用先进AI技术为您定制完美旅程</p>
      </footer>
    </div>
  );
}

export default App;
