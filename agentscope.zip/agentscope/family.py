from http.client import responses
from tkinter.colorchooser import Chooser
from typing import Literal, Union

from agentscope import msghub
from agentscope.agents import DialogAgent, UserAgent
import agentscope
import dashscope
from agentscope.message import Msg
from agentscope.pipelines import sequential_pipeline
from agentscope.agents import ReActAgentV2, UserAgent
from agentscope.service import ServiceToolkit, execute_python_code
from modelscope.utils.nlp.space.ontology import dialog_acts
from pydantic import BaseModel, Field
from qdrant_client import QdrantClient
from sqlalchemy.dialects.mssql.information_schema import sequences
from win32com.servers.dictionary import DictionaryPolicy

dashscope.api_key="sk-870d6bc67fd04cc18cef4c3941e74a56"
agentscope.init(
    model_configs=[
        {
            "config_name": "my_config",
            "model_type": "dashscope_chat",
            "model_name": "qwen-max",
        }
    ]
)
# alice = DialogAgent(
#     name="Alice",
#     sys_prompt="You're a helpful assistant named Alice.",
#     model_config_name="my_config",
# )
#
# bob = DialogAgent(
#     name="Bob",
#     sys_prompt="You're a helpful assistant named Bob.",
#     model_config_name="my_config",
# )
#
# charlie = DialogAgent(
#     name="Charlie",
#     sys_prompt="You're a helpful assistant named Charlie.",
#     model_config_name="my_config",
# )

family_configs = [
    {"name": "张善", "role":"你是张武的爸爸，腰不好不能久坐，在旅游中喜欢注重行程合理性，推荐交通便利的景点"},
    {"name": "李丝", "role":"你是张武的妈妈，在旅游中优先控制总费用，推荐经济型酒店和公共交通"},
    {"name": "张柳", "role":"你是张武的儿子，喜欢调皮，在旅游中希望安排游乐场、主题公园等有趣活动"},
    {"name": "张期", "role":"你是张武的女儿，在旅游中想去漂亮的地方拍照片，不喜欢出去玩太久"}

]
agents_dict = {DialogAgent(config["name"],config["role"],model_config_name="my_config") for config in family_configs}
greeting = Msg(
    name="张武",
    content="我是张武，过几天打算带大家去北京旅游，大家可以聊一聊自己关于这次旅游的想法.",
    role="user",
)
user=DialogAgent("张武","你是张武，你要根据家人的意见选择最终的旅行方案，你的家人有张善（爸爸）李丝（妈妈）张柳（儿子）张期（女儿）",model_config_name="my_config")
response=[]
with msghub( participants=list(agents_dict), announcement=greeting,  ) as hub:

    # The first round of the conversation
  for i in range(2):
    for agent in agents_dict:
        response.append(agent())
    user(Msg("张武", sequences(response), "user"))
# ss=[bob,charlie]
# print(type(ss))
# print(list(agents_dict))

