import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QTextEdit, QPushButton, QLabel,
                             QMessageBox, QTabWidget, QFrame)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QColor, QPalette
import time
from typing import Dict, Any, List
import json

# 保留原代码中的必要部分
from tkinter.colorchooser import Chooser
from typing import Literal, Union
from agentscope import msghub
from agentscope.agents import DialogAgent, UserAgent
import agentscope
import dashscope
from agentscope.message import Msg
from agentscope.pipelines import sequential_pipeline
from agentscope.agents import ReActAgentV2, UserAgent
from agentscope.service import ServiceToolkit, execute_python_code
from modelscope.utils.nlp.space.ontology import dialog_acts
from pydantic import BaseModel, Field
from qdrant_client import QdrantClient
from sqlalchemy.dialects.mssql.information_schema import sequences
from win32com.servers.dictionary import DictionaryPolicy

# 设置Dashscope API密钥
dashscope.api_key = "sk-870d6bc67fd04cc18cef4c3941e74a56"

# 保留家庭和朋友配置
family_configs = [
    {"name": "张善", "role": "你是张武的爸爸，腰不好不能久坐，在旅游中喜欢注重行程合理性，推荐交通便利的景点"},
    {"name": "李丝", "role": "你是张武的妈妈，在旅游中优先控制总费用，推荐经济型酒店和公共交通"},
    {"name": "张柳", "role": "你是张武的儿子，喜欢调皮，在旅游中希望安排游乐场、主题公园等有趣活动"},
    {"name": "张期", "role": "你是张武的女儿，在旅游中想去漂亮的地方拍照片，不喜欢出去玩太久"}
]

friends_configs = [
    {"name": "小红",
     "role": "你是张武的朋友，不喜欢商业化过度的景点（如摆拍式网红打卡地）会破坏自然真实感，不喜欢被游客打扰拍摄和重复的风景（如千篇一律的古镇、景区），更不喜欢快节奏旅行因为无法静心观察细节。"},
    {"name": "小绿",
     "role": "你是张武的朋友，不喜欢拥挤的热门路线和不安全的路线（如无标识的小路、未开发区域）因为风险过高，希望有计划的旅行。"},
    {"name": "小白",
     "role": "你是张武的朋友，不喜欢快餐连锁店，缺乏地方特色和过度包装的“文化体验”（如商业化的民俗表演）。不喜欢浪费食物（如剩饭剩菜）和被推荐“假本地美食”（如用预制菜伪装的手工小吃）。"},
    {"name": "小蓝",
     "role": "你是张武的朋友，不喜欢没有网络信号的偏远地区（如山区、沙漠）因为无法同步数据或求助。不喜欢过度依赖人工服务（如需要排队等导游讲解）因为科技能更高效。"}
]

# 初始化Agentscope
agentscope.init(
    model_configs=[
        {
            "config_name": "my_config",
            "model_type": "dashscope_chat",
            "model_name": "qwen-max",
        }
    ]
)

# 设置工具包
toolkit = ServiceToolkit()
toolkit.add_mcp_servers(
    {
        "mcpServers": {
            "amap-maps": {
                "type": "sse",
                "url": "https://mcp.api-inference.modelscope.net/9f1044ff251243/sse"
            },
            "mcp-trends-hub": {
                "type": "sse",
                "url": "https://mcp.api-inference.modelscope.net/c8b17a7df69b4a/sse"
            },
            "edgeone-pages-mcp": {
                "type": "sse",
                "url": "https://mcp.api-inference.modelscope.net/a6b154c5aeef4d/sse"
            },
            "memory-plus": {
                "type": "sse",
                "url": "https://mcp.api-inference.modelscope.net/eb420b6015354b/sse"
            },
            "12306-mcp": {
                "type": "sse",
                "url": "https://mcp.api-inference.modelscope.net/334df549a6dc4c/sse"
            },
            "mcp-server-chart": {
                "type": "sse",
                "url": "https://mcp.api-inference.modelscope.net/4ecf51cfa7fb4a/sse"
            },
            "howtocook-mcp": {
                "type": "sse",
                "url": "https://mcp.api-inference.modelscope.net/1e2bf7fc3fcb40/sse"
            },
            "variflight-mcp": {
                "type": "sse",
                "url": "https://mcp.api-inference.modelscope.net/504a7c74775540/sse"
            },
            "mcp-ragdocs": {
                "type": "sse",
                "url": "https://mcp.api-inference.modelscope.net/3ea19b25054740/sse"
            }
        }
    }
)

# 创建代理
personal_agent = ReActAgentV2(
    name="personal_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="You're a helpful assistant named personalAgent."
)
family_agent = ReActAgentV2(
    name="family_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="You're a helpful assistant named familyAgent."
)
friends_agent = ReActAgentV2(
    name="friends_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="You're a helpful assistant named friendsAgent."
)
routing_agent = ReActAgentV2(
    name="Routing",
    model_config_name="my_config",
    sys_prompt="You're a routing agent. Your target is to route the user query to the right follow-up task",
    service_toolkit=ServiceToolkit()
)


class RoutingChoice(BaseModel):
    your_choice: Literal[
        'personal travel',
        'friends travel',
        'family travel',
        None
    ] = Field(
        description="Choose the right choice, if the task is too easy or there is no suitable task, select 'None'")
    task_description: Union[str, None] = Field(description="The task description", default=None)


def famliyDialog(plans):
    agents_dict = {DialogAgent(config["name"], config["role"], model_config_name="my_config") for config in
                   family_configs}
    greeting = Msg(
        name="张武",
        content="我是张武，过几天打算带大家去北京旅游，大家简要的聊一聊自己关于这次旅游的想法",
        role="user",
    )
    user = DialogAgent("张武",
                       "你是张武，你要根据家人的意见选择最终的旅行方案，你的家人有张善（爸爸）李丝（妈妈）张柳（儿子）张期（女儿）",
                       model_config_name="my_config")
    response = []
    with msghub(participants=list(agents_dict), announcement=greeting, ) as hub:
        for agent in agents_dict:
            response.append(agent())
        finalOutput = user(Msg("张武", str(response), "user"))
    return str(finalOutput)


def friendsDialog(plans):
    agents_dict = {DialogAgent(config["name"], config["role"], model_config_name="my_config") for config in
                   friends_configs}
    greeting = Msg(
        name="张武",
        content="我是张武，大家简要的聊一聊自己关于这次旅游的想法",
        role="user",
    )
    user = DialogAgent("张武",
                       "你是张武，要根据朋友和自己的意见制定合适的旅游计划",
                       model_config_name="my_config")
    response = []
    with msghub(participants=list(agents_dict), announcement=greeting, ) as hub:
        for agent in agents_dict:
            response.append(agent())
        finalOutput = user(Msg("张武", str(response), "user"))
    return str(finalOutput)


# 创建QT界面类
class TravelPlannerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.setupAgents()

    def setupAgents(self):
        """设置代理和相关配置"""
        self.running = False

    def initUI(self):
        """初始化用户界面"""
        self.setWindowTitle('旅行计划助手')
        self.setGeometry(100, 100, 900, 700)

        # 创建中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 主布局
        main_layout = QVBoxLayout(central_widget)

        # 标题标签
        title_label = QLabel("智能旅行计划助手")
        title_font = QFont("SimHei", 16, QFont.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("margin: 10px;")
        main_layout.addWidget(title_label)

        # 分割线
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        main_layout.addWidget(line)

        # 创建选项卡
        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget, 1)

        # 个人旅行选项卡
        personal_tab = QWidget()
        personal_layout = QVBoxLayout(personal_tab)
        self.tab_widget.addTab(personal_tab, "个人旅行")

        # 朋友旅行选项卡
        friends_tab = QWidget()
        friends_layout = QVBoxLayout(friends_tab)
        self.tab_widget.addTab(friends_tab, "朋友旅行")

        # 家庭旅行选项卡
        family_tab = QWidget()
        family_layout = QVBoxLayout(family_tab)
        self.tab_widget.addTab(family_tab, "家庭旅行")

        # 通用输入和输出区域 - 为每个选项卡设置类似的布局
        for tab, tab_name in [(personal_tab, "个人"), (friends_tab, "朋友"), (family_tab, "家庭")]:
            if tab == personal_tab:
                layout = personal_layout
            elif tab == friends_tab:
                layout = friends_layout
            else:
                layout = family_layout

            # 输入区域
            input_frame = QFrame()
            input_frame.setFrameShape(QFrame.StyledPanel)
            input_layout = QVBoxLayout(input_frame)

            input_label = QLabel(f"{tab_name}旅行计划输入:")
            input_label.setFont(QFont("SimHei", 12))
            input_layout.addWidget(input_label)

            self.input_text = QTextEdit()
            self.input_text.setPlaceholderText("请输入旅行计划信息，例如：'我想去北京旅游，喜欢历史文化景点'")
            self.input_text.setMinimumHeight(100)
            input_layout.addWidget(self.input_text)

            # 按钮区域
            button_layout = QHBoxLayout()

            self.generate_button = QPushButton("生成旅行计划")
            self.generate_button.setFont(QFont("SimHei", 11))
            self.generate_button.clicked.connect(self.generatePlan)
            button_layout.addWidget(self.generate_button)

            self.clear_button = QPushButton("清空输入")
            self.clear_button.setFont(QFont("SimHei", 11))
            self.clear_button.clicked.connect(self.clearInput)
            button_layout.addWidget(self.clear_button)

            input_layout.addLayout(button_layout)
            layout.addWidget(input_frame)

            # 输出区域
            output_frame = QFrame()
            output_frame.setFrameShape(QFrame.StyledPanel)
            output_layout = QVBoxLayout(output_frame)

            output_label = QLabel(f"{tab_name}旅行计划结果:")
            output_label.setFont(QFont("SimHei", 12))
            output_layout.addWidget(output_label)

            self.output_text = QTextEdit()
            self.output_text.setReadOnly(True)
            self.output_text.setMinimumHeight(300)
            output_layout.addWidget(self.output_text)

            layout.addWidget(output_frame)

        # 状态栏
        self.statusBar().showMessage('就绪')

        # 样式设置
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QFrame {
                background-color: white;
                border-radius: 5px;
                margin: 5px;
            }
            QLabel {
                color: #333;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border-radius: 5px;
                padding: 8px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QTabWidget::tab {
                background-color: #e0e0e0;
                border: 1px solid #c0c0c0;
                border-bottom: none;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
                padding: 5px 15px;
            }
            QTabWidget::tab:selected {
                background-color: white;
                border-bottom: 1px solid white;
            }
        """)

    def clearInput(self):
        """清空输入框"""
        self.input_text.clear()

    def generatePlan(self):
        """生成旅行计划"""
        plans = self.input_text.toPlainText().strip()
        if not plans:
            QMessageBox.warning(self, "警告", "请输入旅行计划信息")
            return

        self.statusBar().showMessage('正在生成旅行计划...')
        self.generate_button.setEnabled(False)

        # 确定当前选中的选项卡
        current_tab = self.tab_widget.currentIndex()
        tab_names = ["personal travel", "friends travel", "family travel"]
        plan_type = tab_names[current_tab]

        # 模拟长时间运行的任务，使用线程处理
        self.plan_thread = PlanGenerationThread(plans, plan_type)
        self.plan_thread.result_ready.connect(self.displayResult)
        self.plan_thread.finished.connect(self.planGenerationFinished)
        self.plan_thread.start()

    def displayResult(self, result):
        """显示生成的旅行计划结果"""
        self.output_text.setText(result)

    def planGenerationFinished(self):
        """计划生成完成后的处理"""
        self.statusBar().showMessage('旅行计划生成完成')
        self.generate_button.setEnabled(True)

    def closeEvent(self, event):
        """关闭应用程序时的处理"""
        reply = QMessageBox.question(self, '确认退出', '确定要退出旅行计划助手吗？',
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()


class PlanGenerationThread(QThread):
    """计划生成线程，用于在后台处理耗时任务"""
    result_ready = pyqtSignal(str)

    def __init__(self, plans, plan_type):
        super().__init__()
        self.plans = plans
        self.plan_type = plan_type

    def run(self):
        """线程执行函数"""
        try:
            msg = Msg("user", self.plans, "user")
            res_msg = routing_agent(
                msg,
                structured_model=RoutingChoice
            )

            result = "旅行计划生成结果：\n\n"

            if self.plan_type == "personal travel":
                personal_msg = personal_agent(msg)
                result += f"个人旅行建议：\n{personal_msg.content}\n\n"
            elif self.plan_type == "friends travel":
                output = friendsDialog(self.plans)
                content = output + self.plans
                friendMsg = Msg("user", content, "user")
                friends_msg = friends_agent(friendMsg)
                result += f"朋友旅行建议：\n{friends_msg.content}\n\n"
            elif self.plan_type == "family travel":
                output = famliyDialog(self.plans)
                content = output + self.plans
                familyMsg = Msg("user", content, "user")
                family_msg = family_agent(familyMsg)
                result += f"家庭旅行建议：\n{family_msg.content}\n\n"

            # 模拟耗时操作
            time.sleep(2)  # 实际应用中可移除，这里仅作演示

            self.result_ready.emit(result)
        except Exception as e:
            self.result_ready.emit(f"生成旅行计划时出错：{str(e)}")


# 主函数
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = TravelPlannerApp()
    window.show()
    sys.exit(app.exec_())