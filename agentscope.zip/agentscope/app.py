from typing import Literal, Union

from agentscope.message import Msg
from agentscope.service import ServiceToolkit
from flask import Flask, request, jsonify, render_template_string
from agentscope import msghub
from agentscope.agents import DialogAgent, ReActAgentV2
import agentscope
import dashscope
from pydantic import BaseModel, Field
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # 启用跨域支持

dashscope.api_key = "sk-870d6bc67fd04cc18cef4c3941e74a56"
family_configs = [
    {"name": "张善", "role": "你是张武的爸爸，腰不好不能久坐，在旅游中喜欢注重行程合理性，推荐交通便利的景点"},
    {"name": "李丝", "role": "你是张武的妈妈，在旅游中优先控制总费用，推荐经济型酒店和公共交通"},
    {"name": "张柳", "role": "你是张武的儿子，喜欢调皮，在旅游中希望安排游乐场、主题公园等有趣活动"},
    {"name": "张期", "role": "你是张武的女儿，在旅游中想去漂亮的地方拍照片，不喜欢出去玩太久"}
]
friends_configs = [
    {"name": "小红", "role": "你是张武的朋友，不喜欢商业化过度的景点（如摆拍式网红打卡地）会破坏自然真实感，不喜欢被游客打扰拍摄和重复的风景（如千篇一律的古镇、景区），更不喜欢快节奏旅行因为无法静心观察细节。"},
    {"name": "小绿", "role": "你是张武的朋友，不喜欢拥挤的热门路线和不安全的路线（如无标识的小路、未开发区域）因为风险过高，希望有计划的旅行。"},
    {"name": "小白", "role": "你是张武的朋友，不喜欢快餐连锁店，缺乏地方特色和过度包装的“文化体验”（如商业化的民俗表演）。不喜欢浪费食物（如剩饭剩菜）和被推荐“假本地美食”（如用预制菜伪装的手工小吃）。"},
    {"name": "小蓝", "role": "你是张武的朋友，不喜欢没有网络信号的偏远地区（如山区、沙漠）因为无法同步数据或求助。不喜欢过度依赖人工服务（如需要排队等导游讲解）因为科技能更高效。"}
]

agentscope.init(
    model_configs=[
        {
            "config_name": "my_config",
            "model_type": "dashscope_chat",
            "model_name": "qwen-max",
        }
    ]
)

toolkit = ServiceToolkit()
toolkit.add_mcp_servers(
    {
        "mcpServers": {
            "amap-maps": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/9f1044ff251243/sse"},
            "mcp-trends-hub": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/c8b17a7df69b4a/sse"},
            "edgeone-pages-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/a6b154c5aeef4d/sse"},
            "memory-plus": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/eb420b6015354b/sse"},
            "12306-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/334df549a6dc4c/sse"},
            "mcp-server-chart": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/4ecf51cfa7fb4a/sse"},
            "howtocook-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/1e2bf7fc3fcb40/sse"},
            "variflight-mcp": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/504a7c74775540/sse"},
            "mcp-ragdocs": {"type": "sse", "url": "https://mcp.api-inference.modelscope.net/3ea19b25054740/sse"},
        }
    }
)

personal_agent = ReActAgentV2(
    name="personal_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="You're a helpful assistant named personalAgent."
)
family_agent = ReActAgentV2(
    name="family_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="You're a helpful assistant named familyAgent."
)
friends_agent = ReActAgentV2(
    name="friends_agent",
    model_config_name="my_config",
    service_toolkit=toolkit,
    sys_prompt="You're a helpful assistant named friendsAgent."
)
routing_agent = ReActAgentV2(
    name="Routing",
    model_config_name="my_config",
    sys_prompt="You're a routing agent. Your target is to route the user query to the right follow-up task",
    service_toolkit=ServiceToolkit()
)

class RoutingChoice(BaseModel):
    your_choice: Literal[
        'personal travel',
        'friends travel',
        'family travel',
        None
    ] = Field(description="Choose the right choice, if the task is too easy or there is no suitable task, select 'None'")
    task_description: Union[str, None] = Field(description="The task description", default=None)

def familyDialog(plans):
    agents_dict = [DialogAgent(config["name"], config["role"], model_config_name="my_config") for config in family_configs]
    greeting = Msg(
        name="张武",
        content="我是张武，过几天打算带大家去北京旅游，大家简要的聊一聊自己关于这次旅游的想法",
        role="user",
    )
    user = DialogAgent("张武",
                       "你是张武，你要根据家人的意见选择最终的旅行方案，你的家人有张善（爸爸）李丝（妈妈）张柳（儿子）张期（女儿）",
                       model_config_name="my_config")
    response = []
    with msghub(participants=agents_dict, announcement=greeting) as hub:
        for agent in agents_dict:
            response.append(agent())
        finalOutput = user(Msg("张武", str(response), "user"))
        return str(finalOutput)

def friendsDialog(plans):
    agents_dict = [DialogAgent(config["name"], config["role"], model_config_name="my_config") for config in friends_configs]
    greeting = Msg(
        name="张武",
        content="我是张武，大家简要的聊一聊自己关于这次旅游的想法",
        role="user",
    )
    user = DialogAgent("张武",
                       "你是张武，要根据朋友和自己的意见制定合适的旅游计划",
                       model_config_name="my_config")
    response = []
    with msghub(participants=agents_dict, announcement=greeting) as hub:
        for agent in agents_dict:
            response.append(agent())
        finalOutput = user(Msg("张武", str(response), "user"))
        return str(finalOutput)

@app.route("/")
def index():
    return """
    <h1>旅行计划系统</h1>
    <p>请前往 <a href="/plan">/plan</a> 页面输入旅行计划信息。</p>
    """

@app.route("/plan")
def plan_form():
    return """
    <h1>旅行计划输入</h1>
    <form onsubmit="submitPlan(event)">
      <textarea id="input" rows="5" cols="50" placeholder="请输入旅行计划信息..."></textarea><br><br>
      <button type="submit">提交</button>
    </form>
    <h2>结果：</h2>
    <pre id="output"></pre>

    <script>
      async function submitPlan(event) {
        event.preventDefault();
        const input = document.getElementById("input").value;
        const response = await fetch("/api/plan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ input }),
        });
        const data = await response.json();
        if (data.error) {
          document.getElementById("output").textContent = "错误：" + data.error;
        } else {
          document.getElementById("output").textContent = data.output;
        }
      }
    </script>
    """

@app.route("/api/plan", methods=["POST"])
def handle_travel_plan():
    try:
        data = request.json
        plans = data.get("input", "")

        # 调用原始代码逻辑
        msg = Msg("user", plans, "user")
        res_msg = routing_agent(msg, structured_model=RoutingChoice)

        result = ""
        if res_msg.metadata["your_choice"] == "personal travel":
            result = personal_agent(msg).content
        elif res_msg.metadata["your_choice"] == "friends travel":
            output = friendsDialog(plans)
            friendMsg = Msg("user", output + plans, "user")
            result = friends_agent(friendMsg).content
        elif res_msg.metadata["your_choice"] == "family travel":
            output = familyDialog(plans)
            print("output: ", output)
            familyMsg = Msg("user", output + plans, "user")
            print("familyMsg: ",familyMsg)
            result = family_agent(familyMsg).content

        return jsonify({"output": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)